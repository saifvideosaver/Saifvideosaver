# Saif Video Saver v1.1

Starter Android app project.

Added:
- Home screen
- Android system video picker (video/*)
- Basic local VideoView player
- My Videos screen
- Settings screen
- Material 3 dark interface

Important: this version works with video files the user selects from the device. It does not bypass YouTube, TikTok, or other platform download restrictions.
