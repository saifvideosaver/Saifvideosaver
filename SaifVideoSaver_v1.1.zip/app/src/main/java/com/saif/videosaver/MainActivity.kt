package com.saif.videosaver

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import android.widget.VideoView

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SaifVideoSaverApp() }
    }
}

@Composable
fun SaifVideoSaverApp() {
    var screen by remember { mutableStateOf("Home") }
    var selectedUri by remember { mutableStateOf<Uri?>(null) }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(bottomBar = {
            NavigationBar {
                NavigationBarItem(screen=="Home", {screen="Home"}, icon={Icon(Icons.Default.Home,null)}, label={Text("Home")})
                NavigationBarItem(screen=="Videos", {screen="Videos"}, icon={Icon(Icons.Default.VideoLibrary,null)}, label={Text("My Videos")})
                NavigationBarItem(screen=="Settings", {screen="Settings"}, icon={Icon(Icons.Default.Settings,null)}, label={Text("Settings")})
            }
        }) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when(screen) {
                    "Home" -> HomeScreen(
                        onPicked = { uri -> selectedUri = uri; screen = "Player" },
                        openVideos = { screen = "Videos" }
                    )
                    "Videos" -> VideosScreen(onOpen = { screen = "Player" })
                    "Player" -> VideoPlayerScreen(selectedUri, onBack = { screen = "Home" })
                    else -> SettingsScreen()
                }
            }
        }
    }
}

@Composable
fun HomeScreen(onPicked: (Uri) -> Unit, openVideos: () -> Unit) {
    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let(onPicked) }

    Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment=Alignment.CenterHorizontally) {
        Spacer(Modifier.height(30.dp))
        Icon(Icons.Default.VideoLibrary, null, Modifier.size(82.dp))
        Text("Saif Video Saver", fontSize=30.sp)
        Text("Save your own and permitted video files", color=MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(35.dp))
        Button(
            onClick = { picker.launch(arrayOf("video/*")) },
            modifier=Modifier.fillMaxWidth().height(58.dp)
        ) {
            Icon(Icons.Default.Download, null); Spacer(Modifier.width(10.dp)); Text("Choose Video")
        }
        Spacer(Modifier.height(14.dp))
        OutlinedButton(onClick=openVideos, modifier=Modifier.fillMaxWidth().height(58.dp)) {
            Icon(Icons.Default.VideoLibrary, null); Spacer(Modifier.width(10.dp)); Text("My Videos")
        }
    }
}

@Composable
fun VideosScreen(onOpen: () -> Unit) {
    val demo = listOf("Roman_Reigns.mp4", "Nature_Video.mp4", "WWE_Match.mp4", "My_Video.mp4")
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("My Videos", fontSize=28.sp)
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)) {
            items(demo) { name ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(16.dp), verticalAlignment=Alignment.CenterVertically) {
                        Icon(Icons.Default.PlayCircle, null, Modifier.size(42.dp))
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(name)
                            Text("Local video", color=MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick=onOpen) { Icon(Icons.Default.PlayArrow, null) }
                    }
                }
            }
        }
    }
}

@Composable
fun VideoPlayerScreen(uri: Uri?, onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment=Alignment.CenterVertically) {
            IconButton(onClick=onBack) { Icon(Icons.Default.ArrowBack, null) }
            Text("Video Player", fontSize=22.sp)
        }
        if (uri != null) {
            AndroidView(
                factory = { context ->
                    VideoView(context).apply {
                        setVideoURI(uri)
                        setMediaController(android.widget.MediaController(context))
                        setOnPreparedListener { it.start() }
                    }
                },
                modifier = Modifier.fillMaxWidth().weight(1f)
            )
        } else {
            Box(Modifier.fillMaxSize(), contentAlignment=Alignment.Center) {
                Text("No video selected")
            }
        }
    }
}

@Composable
fun SettingsScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Settings", fontSize=28.sp)
        Spacer(Modifier.height(16.dp))
        ListItem(headlineContent={Text("Video Quality")}, supportingContent={Text("Use original file quality")}, leadingContent={Icon(Icons.Default.HighQuality,null)})
        ListItem(headlineContent={Text("Notifications")}, leadingContent={Icon(Icons.Default.Notifications,null)})
        ListItem(headlineContent={Text("About App")}, supportingContent={Text("Saif Video Saver 1.1")}, leadingContent={Icon(Icons.Default.Info,null)})
    }
}
